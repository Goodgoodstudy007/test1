from selenium import webdriver
chrome_options = webdriver.ChromeOptions()
chrome_options.add_experimental_option('useAutomationExtension',False)
chrome_options.add_argument("disable-blink-features")
chrome_options.add_argument("disable-blink-features=AutomationControlled")
chrome_options.set_headless()
d = webdriver.Chrome(executable_path=r'C:\Users\lx\Desktop\chromedriver\chromedriver.exe',options=chrome_options)
d.get('https://www.douyin.com/')
d.get('https://www.douyin.com/video/6973991983329168644?previous_page=main_page')

for i in d.get_cookies():
    print(i['name'],i['value'])

d.close()
d.quit()