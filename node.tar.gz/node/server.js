const express = require('express');
const app = express();
var bodyParser = require('body-parser');
app.use(bodyParser());

var signs = require ('./signature')


app.post('/sign',
    function (req, res) {
        let result = req.body;
        let url = result.url;
        result = signs.get_sign(url);
        console.log(result);
        res.send(result)
    }
    );

app.listen(8003, () => {
    console.log('开服务，端口8003')
    });
