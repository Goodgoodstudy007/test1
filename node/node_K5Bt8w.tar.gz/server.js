const express = require('express');
const app = express();
var bodyParser = require('body-parser');
var proxy   = require('express-http-proxy')
// const { createProxyMiddleware } = require('http-proxy-middleware')

app.use(bodyParser());

var signs = require ('./signature')

app.post('/user_profile',
    function (req, res) {
        let result = req.body;
        let kw = result.kw;
        result = signs.user_profile(kw);
        res.send(result)
    }
);

app.post('/comment',proxy(req => {
        return 'http://'+req.body.proxy_ip+":"+req.body.proxy_port
    },{
    proxyReqOptDecorator:function(proxyReq,originalReq){
        return proxyReq
    },
    userResDecorator: function(proxyRes, proxyResData, userReq, userRes) {
        let result = userReq.body;
        let kw = result.kw;
        let offset = result.offset;
        let count = result.count;
        result = signs.comment(kw,offset,count);
        return result
    },
}));
app.post('/search_item',proxy(req => {
        return 'http://'+req.body.proxy_ip+":"+req.body.proxy_port
    },{
    proxyReqOptDecorator:function(proxyReq,originalReq){
        return proxyReq
    },
    userResDecorator: function(proxyRes, proxyResData, userReq, userRes) {
        let result = userReq.body;
        let kw = result.kw;
        let count = result.count;
        let offset = result.offset;
        let sort_type = result.sort_type;
        let publish_time = result.publish_time;
        result = signs.search_item(kw,count,offset,sort_type,publish_time);
        return result
    },
}));

app.post('/aweme_post',proxy(req => {
        return 'http://'+req.body.proxy_ip+":"+req.body.proxy_port
    },{
    proxyReqOptDecorator:function(proxyReq,originalReq){
        return proxyReq
    },
    userResDecorator: function(proxyRes, proxyResData, userReq, userRes) {
        let result = userReq.body;
        let kw = result.kw;
        let count = result.count;
        let max_cursor = result.max_cursor;
        result = signs.aweme_post(kw,count,max_cursor);
        return result
    },
}));

app.post('/follow',proxy(req => {
        return 'http://'+req.body.proxy_ip+":"+req.body.proxy_port
    },{
    proxyReqOptDecorator:function(proxyReq,originalReq){
        return proxyReq
    },
    userResDecorator: function(proxyRes, proxyResData, userReq, userRes) {
        let result = userReq.body;
        let token = result.token;
        result = signs.follow(token);
        return result
    },
}));

app.listen(8003, () => {
    console.log('开服务，端口8003')
});
